package com.example.apiforstudentmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiforstudentmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiforstudentmanagementApplication.class, args);
	}

}
