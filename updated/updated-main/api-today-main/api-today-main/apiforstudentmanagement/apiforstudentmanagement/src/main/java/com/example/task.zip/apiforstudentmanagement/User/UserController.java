package com.example.apiforstudentmanagement.User;

import com.example.apiforstudentmanagement.jwtutil.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("api/v1/student")
public class UserController {

@Autowired
    private UserService userService;
@Autowired /// new CHANGE
private JwtUtils jwtUtils;


   /* public UserController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }*/
   @Autowired(required = false)//new CHANGE
    private User user;


    @PostMapping("save")
    public ResponseEntity<User> adduser(@RequestBody User user)
{
    User userSaved = userService.adduser(user);
    return new ResponseEntity<User>(userSaved, HttpStatus.CREATED);
}

@GetMapping("alluser")
    public ResponseEntity<List<User>> getalluser()
{
    List<User> userlist = userService.getalluser();
    return new ResponseEntity<List<User>>(userlist,HttpStatus.OK);
}

@GetMapping("{id}")
    public ResponseEntity<User> getuserById(@PathVariable Long id)
{
    User userretrive = userService.getuserById(id);
    return new ResponseEntity<User>(userretrive,HttpStatus.OK);
}

@DeleteMapping("/delete/{id}")
public ResponseEntity<Void> deleteuserById(@PathVariable Long id)
    {
        userService.deleteUserById(id);
                return new ResponseEntity<Void>(HttpStatus.ACCEPTED);
    }

    /*@PutMapping("update")
    public ResponseEntity<User> updateUser(@RequestBody User user)
    {
        User userUpdated = userService.adduser(user);
                return new ResponseEntity<User>(userUpdated, HttpStatus.CREATED);
    }*/


    /*@PostMapping("login")
    public ResponseEntity<Object> login(@RequestBody LoginRequest loginRequest) {
    try {
        Optional<User> user1 = userService.getdetails(loginRequest.getEmail());
        if (user1.isPresent()) {
            return ResponseEntity.status(200).body(user1);
        } else {
            return ResponseEntity.status(404).body(new Login404Error("hello"));
        }
    }catch (Exception e){
        throw new IllegalStateException(e.getMessage());
    }

    }
*/
//        User userSaved = userServiceInterface.adduser(loginRequest);
//        return new ResponseEntity<User>(userSaved, HttpStatus.CREATED);

@PostMapping(value ="create")
public ResponseEntity<Object> create(@Valid @RequestBody User user)
{
    try
     {
         Optional<User> log = userService.method(user.getEmail());
         if(log.isPresent())
         {
             return ResponseEntity.status(403).body(new Login403Error("Email is already present"));
         }
         else if (user.getEmail()==""||user.getPassword()==""||user.getFirstName()==""||user.getLastName()=="")
         {
             return ResponseEntity.status(403).body(new Login403Error("Validation error"));
         }
         else {
             User userSaved = userService.adduser(user);
             return ResponseEntity.status(201).body(userSaved);
         }
     }
    catch(Exception e)
    {
        throw new IllegalStateException(e.getMessage());
    }


}

@PostMapping(value = "/login")
    public ResponseEntity<Object> login( @Valid @RequestBody LoginRequest loginRequest ,User user) throws Exception {
    User loginUser =(User) userService.Login(loginRequest);
    JwtUtils jwtUtils = new JwtUtils();
    String token = jwtUtils.generateJwt(loginUser);
    try {
        Optional<User> log = userService.method(loginRequest.getEmail());
        if (log.isPresent()) {
            return ResponseEntity.status(200).body(new Login200Error("Bearer" , token));
        }
         else if (loginRequest.getEmail() == "" && loginRequest.getPassword() == "")
            {
                return ResponseEntity.status(500).body(new Login404Error("Internal Server Error"));
            }
            else
            {
                return ResponseEntity.status(404).body(new Login404Error("email or password does not exist"));
            }}

    catch (Exception ex) {
        throw new RuntimeException(ex);
    }
}
            /*if (loginRequest.getEmail() == "") {
                return ResponseEntity.status(404).body(new Login404Error("Email or password does not match"));
            } else if (loginRequest.getPassword() == "") {
                return ResponseEntity.status(404).body(new Login404Error("Email or password does not match"));
            } else if (log.isPresent()) {
                return ResponseEntity.status(200).body(log);
            }*/
/*@Autowired
private UserRepository userRepository;

    @PutMapping("{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id,@RequestBody User user) throws ResourceIOException
    {
        User user2 = userRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException);
        user.setEmail(user.getEmail());
        user.setFirstName(user.getFirstName());
        user.setLastName(user.getLastName());
        final User updatedUser = userRepository.save(user);
        return ResponseEntity.ok(updatedUser);

    }*/



       /* User userUpdated = userService.adduser(user);
        return new ResponseEntity<User>(userUpdated, HttpStatus.CREATED);*/
    @PutMapping(path = "{id}")
public void UpdateStudent(
        @PathVariable Long id, @RequestParam(required = false) String name,
        @RequestParam(required = false) String email ,@RequestParam(required =false) String password)
    {
        userService.updateStudent(id,name,email,password);
    }
}







