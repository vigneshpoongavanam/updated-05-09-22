package com.example.apiforstudentmanagement.User;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository <User, Long>
{

    /*@Query(value = "select * from tbl_user where email=?1 and password=?2",nativeQuery = true)
    User loginUser(@PathVariable("email") String email,@PathVariable("password") String password);

    Optional<User> FindByEmail(@PathVariable("email") String email);*/
   // Object getByEmail(String email);

  //  Object getByMail(String email);
    @Query(value = "Select * from tbl_user where email=?1 and password=?2",nativeQuery = true)
    User AdminLogin(@PathVariable("email") String email,@PathVariable("password") String password);

    Optional<User> findByEmail(@PathVariable("email") String email);


}
